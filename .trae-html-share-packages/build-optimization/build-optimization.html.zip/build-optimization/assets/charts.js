(function () {
  var style = getComputedStyle(document.documentElement);
  var accent = style.getPropertyValue('--accent').trim();
  var accent2 = style.getPropertyValue('--accent2').trim();
  var ink = style.getPropertyValue('--ink').trim();
  var muted = style.getPropertyValue('--muted').trim();
  var rule = style.getPropertyValue('--rule').trim();
  var bg2 = style.getPropertyValue('--bg2').trim();
  var green = style.getPropertyValue('--green').trim();
  var red = style.getPropertyValue('--red').trim();

  // --- Chart 1: Build Time Comparison ---
  var chart1 = echarts.init(document.getElementById('chart-buildtime'), null, { renderer: 'svg' });
  chart1.setOption({
    animation: false,
    tooltip: {
      trigger: 'axis',
      axisPointer: { type: 'shadow' },
      appendToBody: true,
      backgroundColor: bg2,
      borderColor: rule,
      textStyle: { color: ink, fontSize: 12 }
    },
    legend: {
      data: ['优化前', '优化后'],
      textStyle: { color: muted, fontSize: 12 },
      top: 8,
      itemWidth: 12,
      itemHeight: 12
    },
    grid: { left: 130, right: 40, top: 50, bottom: 30 },
    xAxis: {
      type: 'value',
      name: '秒',
      nameTextStyle: { color: muted, fontSize: 11 },
      axisLine: { lineStyle: { color: rule } },
      axisLabel: { color: muted, fontSize: 11 },
      splitLine: { lineStyle: { color: rule, opacity: 0.3 } }
    },
    yAxis: {
      type: 'category',
      data: ['前端依赖安装', '前端 lint+format', '前端构建', 'Rust 依赖编译', 'Rust 项目编译', '镜像打包'],
      axisLine: { lineStyle: { color: rule } },
      axisLabel: { color: ink, fontSize: 12 }
    },
    series: [
      {
        name: '优化前',
        type: 'bar',
        data: [60, 45, 30, 360, 90, 15],
        itemStyle: { color: red, borderRadius: [0, 4, 4, 0] },
        barWidth: 18,
        label: {
          show: true,
          position: 'right',
          color: muted,
          fontSize: 11,
          formatter: '{c}s'
        }
      },
      {
        name: '优化后',
        type: 'bar',
        data: [60, 0, 30, 120, 45, 10],
        itemStyle: { color: green, borderRadius: [0, 4, 4, 0] },
        barWidth: 18,
        label: {
          show: true,
          position: 'right',
          color: muted,
          fontSize: 11,
          formatter: '{c}s'
        }
      }
    ]
  });
  window.addEventListener('resize', function () { chart1.resize(); });

  // --- Chart 2: Dependency Count ---
  var chart2 = echarts.init(document.getElementById('chart-deps'), null, { renderer: 'svg' });
  chart2.setOption({
    animation: false,
    tooltip: {
      trigger: 'item',
      appendToBody: true,
      backgroundColor: bg2,
      borderColor: rule,
      textStyle: { color: ink, fontSize: 12 }
    },
    legend: {
      bottom: 8,
      textStyle: { color: muted, fontSize: 12 },
      itemWidth: 12,
      itemHeight: 12
    },
    series: [
      {
        name: '优化前',
        type: 'pie',
        radius: ['35%', '60%'],
        center: ['25%', '45%'],
        label: {
          show: true,
          color: ink,
          fontSize: 11,
          formatter: '{b}\n{c} 个'
        },
        labelLine: { lineStyle: { color: rule } },
        data: [
          { value: 180, name: 'sea-orm + sqlx', itemStyle: { color: red } },
          { value: 120, name: 'tokio (full)', itemStyle: { color: accent2 } },
          { value: 80, name: 'reqwest (native-tls)', itemStyle: { color: '#d29922' } },
          { value: 250, name: '其他必要依赖', itemStyle: { color: accent } }
        ]
      },
      {
        name: '优化后',
        type: 'pie',
        radius: ['35%', '60%'],
        center: ['75%', '45%'],
        label: {
          show: true,
          color: ink,
          fontSize: 11,
          formatter: '{b}\n{c} 个'
        },
        labelLine: { lineStyle: { color: rule } },
        data: [
          { value: 0, name: 'sea-orm + sqlx', itemStyle: { color: red } },
          { value: 60, name: 'tokio (精简)', itemStyle: { color: accent2 } },
          { value: 50, name: 'reqwest (rustls)', itemStyle: { color: '#d29922' } },
          { value: 250, name: '其他必要依赖', itemStyle: { color: accent } }
        ]
      }
    ],
    title: [
      { text: '优化前 ~630', left: '25%', top: '5%', textAlign: 'center', textStyle: { color: red, fontSize: 14, fontWeight: 700 } },
      { text: '优化后 ~360', left: '75%', top: '5%', textAlign: 'center', textStyle: { color: green, fontSize: 14, fontWeight: 700 } }
    ]
  });
  window.addEventListener('resize', function () { chart2.resize(); });
})();
